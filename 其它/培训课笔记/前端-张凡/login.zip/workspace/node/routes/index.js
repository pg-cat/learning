var express = require('express');
var router = express.Router();
var request = require('request');

var str = null;
var reqData = '';
// 把中文转化成unicode
// function tounicode(data)
// {
//    var str ='';
//    for(var i=0;i<data.length;i++)
//    {
//       str+="\\u"+parseInt(data[i].charCodeAt(0),10).toString(16);
//    }
//    return str;
// }
/* GET home page. */
// 如果是Php或者python，他会在发送请求的时候自动把中文转化
router.get('/', function(req, res, next) {
  console.log(req.query.cityname);

  reqData = encodeURI(req.query.cityname);

  request({
    url:'http://v.juhe.cn/weather/index?cityname='+ reqData +'&key=f3d74c635ec20a44d66f265c251b3942',
    headers: {
        "content-type": "application/json",
    }
  },function(error,ress,body){
      console.log(error);
      console.log(ress);
      str = ress;
  })
  res.send(str);
});

module.exports = router;
