var express = require('express');
var router = express.Router();
var one = null;

var two = null;
router.get('/login',function(req,res){
  if(req.query.name === 'zhangfan' && req.query.password === '345'){
     var msg = {
      name : req.query.name,
      password : req.query.password
    }
    req.session.user = msg;
    console.log('session存储成功');
    var msg = {
      status:200
    }
    res.send(msg);
  }
})

router.get('/loginIn',function(req,res){

  if(req.query.name){
    var msg = {
      status:200
    }
    res.send(msg);
  }else{
    var msg = {
      status:404
    }
    res.send(msg);
  }
})

router.get('/loginout',function(req,res){
  res.send(200);
})

module.exports = router;
