var express = require('express');
var router = express.Router();
var zhangfan = {
  name : 'zhangfan',
  password: '456'
}

/* GET users listing. */
router.get('/', function(req, res, next) {

  // 判断session是否存储完成

  console.log(req.session.user);
  if(req.session.user){  //  如果session里面有用户信息，直接登录，并且跳转
    var msg = {
      name : req.session.user.name,
      show : true,
    }
    res.render('index',{ message:msg });
  }else{  // 如果没有用户信息，那么跳转到登录页
    var msg = {
      show:false
    }
    res.render('index',{ message:msg });
  }


});

router.get('/login',function(req,res){
  var user = {
    name : req.query.name,
    password : req.query.password
  }

  // 此时收到的用户名通过数据库查询，查询数据库用户的密码
  // 两个进行比对，如果比对成功，那么登录成功
  if(zhangfan.name === user.name && zhangfan.password === user.password){
    // 跳转到登陆成功页面
    // res.redirect('login');
    // 用户名，提示登陆成功，控制两个元素的显示状态
    var msg = {
      name : user.name,
      show : true,
    }
    // 设置session
    req.session.user = user;


    res.render('index',{ message:msg });

    // console.log(user);
  }else{
    res.send(404);
    console.log(user);
    console.log('用户名密码错误');
  }

})

router.get('/loginout',function(req,res){
    // req.session.cookie.masAge = 0;
    // 另一种方法
    req.session.destroy((err)=>{
      console.log(err);
    })
    res.send('退出登录');
})

module.exports = router;
