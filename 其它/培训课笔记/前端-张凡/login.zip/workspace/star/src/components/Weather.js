import React from 'react';


class Weather extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data:false
    };
  }
  componentDidMount(){
    if(localStorage.getItem('name')){
      fetch('http://localhost:8080/user/loginIn?name='+ localStorage.getItem('name')).then(res => {
        return res.json();
      }).then(res =>{
        console.log(res);
        if(res.status === 200){
          this.setState({
            data:true
          })
        }else{
          return
        }
      })
    }else{
      return
    }

  }
  submit(){
    var user = {
      name : this.name.value,
      password:this.pass.value
    }

    fetch('http://localhost:8080/user/login?name='+this.name.value + '&password=' + this.pass.value).then(res => {
      return res.json();
    }).then(res =>{
      console.log(res);
      if(res.status === 200){
        this.setState({
          data:true
        })
      }
      localStorage.setItem('name','zhangfan');
    })
  }
  loginOut(){
    localStorage.removeItem("name");
    this.setState({
      data:false
    })
  }
  render() {
    return (
      <div id="app">
          {this.state.data?(
            <div>
              <h1>登陆成功</h1>
              <button onClick={this.loginOut.bind(this)}>退出登录</button>
            </div>
          ) : (
            <div>
              <input type="text" name="name" ref={input => this.name = input} defaultValue="" />
              <input type="password" name="password" ref={input => this.pass = input} defaultValue="" />
              <input type="submit" value="确定" />
              <button onClick={ this.submit.bind(this) } type="button">确定</button>
            </div>
          )}
      </div>
    );
  }
}


export default Weather;
