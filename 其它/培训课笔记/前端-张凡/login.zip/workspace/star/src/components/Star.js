import React from 'react';
import './Star.css';

class Star extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      star:[false,false,false,false,false]
    };
  }

  change(index){

    let arr = this.state.star;

    arr[index] = true;

    this.setState({
      star : arr
    })

    console.log(index);

  }

  changeEnd(index){
    let arr = this.state.star;

    arr[index] = false;

    this.setState({
      star : arr
    })

    console.log(this.state.star);
  }

  render() {
    return (
      <div>
        <div onTouchEnd={this.changeEnd.bind(this,0)} onTouchMove={this.change.bind(this,0)} onTouchStart={this.change.bind(this,0)} className={this.state.star[0]===true?'active one':'one'}>
          <div onTouchEnd={this.changeEnd.bind(this,1)} onTouchMove={this.change.bind(this,1)} onTouchStart={this.change.bind(this,1)} className={this.state.star[1]===true?'active two':'two'}>
          <div onTouchEnd={this.changeEnd.bind(this,2)} onTouchMove={this.change.bind(this,2)} onTouchStart={this.change.bind(this,2)} className={this.state.star[2]===true?'active three':'three'}>
            <div onTouchEnd={this.changeEnd.bind(this,3)} onTouchMove={this.change.bind(this,3)} onTouchStart={this.change.bind(this,3)} className={this.state.star[3]===true?'active four':'four'}>
              <div onTouchEnd={this.changeEnd.bind(this,4)} onTouchMove={this.change.bind(this,4)} onTouchStart={this.change.bind(this,4)} className={this.state.star[4]===true?'active five':'five'}>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    );
  }
}


export default Star;
