# 模板渲染的登录注册

## form 表单标签

  method  提交的请求协议:post/get，put,push,download

  action  提交的地址，url。如果是模板引擎渲染，直接可以提交到断路由上

## express-session session缓存

  缓存到服务器中的数据

  // 引入session 来保存你的用户信息
  var session = require('express-session');

  // 使用session插件
  app.use(session({
    // 信息是否加密
    secret:'secret',
    // 每次强制更新一次
    resave:true,
    // 更新时间
    saveUninitialized:false,
    cookie:{
      // 用户的信息在session中存储多久
      maxAge:1000*60*10
    }
  }))

  存储session信息
  // 设置session
  req.session.user = user;

  退出登录，销毁session信息
  req.session.cookie.masAge = 0;
  // 另一种方法
  req.session.destroy((err)=>{
    console.log(err);
  })
  res.send('退出登录');

# 前后台分离

  前后台分离，我们需要将信息存储到前台的localStorage里面，进行验证

  但是，安全系数不高
