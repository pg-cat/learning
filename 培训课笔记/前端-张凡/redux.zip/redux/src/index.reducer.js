// 声明一个state需要的变量
const gongzi = 10000;

// action部分
const up = {
  type : '涨薪'
}
const down = {
  type : '扣工资'
}

// reducer
const reducer = (state = gongzi,action) => {
  // 通过判断，执行哪个action
  switch (action.type){
    case '涨薪':
      return state += 1000;
    case '扣工资':
      return state -= 100;
    default:
      return state;
  }
}

export default reducer;
