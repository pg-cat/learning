import React,{ Component } from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { Provider} from 'react-redux';
import * as serviceWorker from './serviceWorker';
import { createStore } from 'redux';
import Reducer from './index.reducer';
import App from './App';

// 创建状态树
const store = createStore(Reducer);


ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>
  , document.getElementById('root'));

serviceWorker.unregister();
