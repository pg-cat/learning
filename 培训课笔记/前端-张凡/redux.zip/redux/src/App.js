import React,{ Component } from 'react';
import { connect } from 'react-redux';
class App extends Component{
  render(){
    const { Payup,Paydown } = this.props;
    return (
      <div>
        <h1>{this.props.gongzi}</h1>
        <button onClick={Payup}>涨工资</button>
        <button onClick={Paydown}>扣工资</button>
      </div>
    )
  }
}
// 需要渲染哪个数据
function mapStateToProps(state){
  return {
    gongzi : state,
  }
}

// 通过标签里的函数触发哪些事件
function mapDispatchToProps(dispatch){
  return {
    Payup: ()=>dispatch({type:'涨薪'}),
    Paydown:()=>dispatch({type:'扣工资'})
  }
}

export default App = connect(mapStateToProps,mapDispatchToProps)(App);
