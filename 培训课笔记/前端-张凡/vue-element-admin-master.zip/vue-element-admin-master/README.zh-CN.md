# vue-element-admin

  现在最流行的两种后台管理程序，一个是目前看到的vue-element-admin另一个是ant design pro(react)

  我们只需要更改路由控制，以及请求接口即可，剩下的要操作的比较少

## 侧边栏

  控制侧边栏，直接更改路由配置即可，他会自动生成部分侧边栏
