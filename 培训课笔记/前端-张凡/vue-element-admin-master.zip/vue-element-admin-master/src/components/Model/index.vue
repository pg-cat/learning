<template>
  <div class="model">

    <div class="modelContent">

      <table>
        <tr>
          <td>
            图片id
          </td>
          <td>
            图片标题
          </td>
          <td>
            图片链接
          </td>
          <td>
            跳转地址
          </td>
        </tr>
        <tr>
          <td>
            <slot name="id"></slot>
          </td>
          <td>
            <slot name="title"></slot>
          </td>
          <td>
            <slot name="url"></slot>
          </td>
          <td>
            <slot name="ahref"></slot>
          </td>
        </tr>
      </table>
      <!-- <p v-for = "( item,index ) in obj"> {{ item }}  {{ index }} </p> -->
    </div>

  </div>
</template>

<script>


export default {
  name: 'Model',
  data() {
    return {
    }
  }

}
</script>

<style scoped>
.model{
  width:100%;
  height:100%;
  position:absolute;
  left:0px;
  top:0px;
  background:rgba(0,0,0,0.6);
  z-index:9999;
}
.modelContent{
  background:white;
  width:1400px;
  height:150px;
  margin:100px auto;
  overflow:hidden;
}
td{
  border:1px solid #ccc;
  width:330px;
  text-align:center;
  height:28px;
  line-height: 28px;
}
table{
  margin:20px auto;

}
</style>
