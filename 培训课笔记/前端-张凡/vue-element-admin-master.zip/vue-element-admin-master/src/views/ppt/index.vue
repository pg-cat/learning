<template>
  <div class="app-container">
    <Model  v-show="showModel">
        <input type="text" v-for="(item,index) in obj" :slot="`${index}`" name="" :value="`${item}`">

    </Model>

    <a @click="model" class="document-btn" >添加轮播图</a>

    <table v-loading="listloading">
      <tr>
        <td>id</td>
        <td>图片标题</td>
        <td>图片链接</td>
        <td>跳转链接</td>
        <td>操作</td>
      </tr>
      <tr v-for="(item,index) in list">
        <td>
          <span v-if=" numbers == index ? false : true "> {{ item.id }} </span>
          <input :class="inputs + item.id" v-else type="text" v-model="item.id" name="" value="">
        </td>
        <td>
          <span v-if="numbers == index ? false : true ">{{ item.imgTitle }}</span>
          <input :class="inputs + item.id" v-else type="text" v-model="item.imgTitle" name="" value="">
        </td>
        <td>
          <span v-if="numbers == index ? false : true ">{{ item.imgurl }}</span>
          <input :class="inputs + item.id" v-else type="text" v-model="item.imgurl" name="" value="">
        </td>
        <td>
          <span v-if="numbers == index ? false : true ">{{ item.ahref }}</span>
          <input :class="inputs + item.id" v-else v-model="item.ahref" type="text" name="" value="">
        </td>
        <td>
          <button @click="changeShow(index)" class="btn" v-if="numbers == index ? false : true "  type="button" name="button">修改</button>
          <button @click="success(item.id)" class="btn-new" v-else  type="button" name="button">完成</button>
        </td>
      </tr>
    </table>
    <pagination
    :total="total"
    :page.sync="listQuery.page"
    :limit.sync="listQuery.limit"
    :page-sizes="size"
    @pagination="getList" />


  </div>


</template>

<script>
// 请求地址
import { getData } from '@/api/article'

import Model from '@/components/Model/index'

import Pagination from '@/components/Pagination'

export default {
  name: 'Ppt',
  data() {
    return {
      list:[],
      listloading: true,
      showModel: false,
      total: 0,
      listQuery: {
        page: 1,
        limit: 20,
      },
      size:[5,10,20],
      isShow:true,
      numbers:null,
      inputs:'inputs',
      obj:{
        id:0,
        title:'图片标题',
        url:'图片链接',
        ahref:'跳转链接'
      }
    }
  },
  created() {
    this.getList();
  },
  methods: {
    changeShow:function(num){
      this.numbers = num;
    },
    getList:function(num = 1){
      const that = this;
      getData('http://192.168.31.132:8080/getMsg',num,function(res){
        console.log(res);
        that.list = res.data.data;
        that.listloading = false;
        // res.data.num 是数据的总和
        that.total = res.data.num;
        return res.data.data;
      });
    },
    success:function(nums){

      console.log(document.getElementsByClassName('inputs'+nums));

      // console.log(document.getElementsByClassName('app-container')[0].getElementsByTagName('input'));

    },
    model:function(){

      this.showModel = true;

    }
  },
  components: {
    Model,
    Pagination
  }
}
</script>

<style scoped>
  td{
    border:1px solid #ccc;
    min-width:200px;
    height:28px;
    line-height: 28px;
    text-align:center;
  }
  table{
    width:100%;
  }
  .btn{
    border:none;
    outline:none;
    background:rgb(86,210,205);
    color:white;
    border-radius:4px;
  }
  .btn-new{
    border:none;
    outline:none;
    background:rgb(25,121,254);
    color:white;
    border-radius:4px;
  }
  input{
    outline:none;
    width:100%;
    height:100%;
    line-height: 100%;
    border:1px solid blue;
  }
  .document-btn {
    float: left;
    margin-left: 50px;
    display: block;
    cursor: pointer;
    background: rgb(25,121,254);
    color: white;
    height: 60px;
    width: 200px;
    line-height: 60px;
    font-size: 20px;
    text-align: center;
    margin-bottom:20px;
  }
</style>
