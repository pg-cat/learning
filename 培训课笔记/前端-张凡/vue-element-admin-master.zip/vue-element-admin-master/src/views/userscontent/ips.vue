<template>
  <div class="">

    <h1>这是访问信息页面</h1>

  </div>
</template>

<script>

export default {
  name: 'UsersIps',

}
</script>
