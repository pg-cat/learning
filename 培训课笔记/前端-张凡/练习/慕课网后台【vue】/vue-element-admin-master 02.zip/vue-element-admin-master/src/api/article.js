import axios from 'axios'

export function getData(url,num,callback) {
  axios.get(url,{params:{page:num}}).then(callback);
}


/*
  db.表名称.find({查询条件}).skip(5).limit(5)
  数据库是通过他们来进行分页的
  limit 控制从数据库拿多少条数据
  skip 跳过多少条数据

  db.表名称.find({查询条件}).sort({id:-1})

  sort 数据库内容排序，{根据什么条件进行排序: 1升序，-1降序}

  假如有20条数据，每页5条
  1(1-1*5)   ：   1-5
  skip(0) limit(5)
  2(5)   ：   6-10
  skip(5) limit(5)
  3(10)   ：   11-15
  skip(10) limit(5)
  4(n-1*5)   ：   16-20
  skip() limit(5)

  skip 里面的参数是  显示第几页：n   每页有多少条是m
  (n-1)*m

  db.getCollection('表的名称').count({})  获取当前表有多少条数据
  大括号里面是过滤信息，或者是过滤条件

  对接口，整个项目前后台最麻烦的
*/
