<template>
        <table>
          <tr>
            <td v-for="item in TableMsg">{{ item }}</td>
          </tr>
          <tr v-for="(item,index) in TdMsg">
            <!-- item是List的每一项 -->
            <!-- <td v-for="(items,index) in item" v-for="xiang in ArrMsg">{{ index == xiang }}</td> -->
            <td v-for="xiang in ArrMsg">
              <div v-if=" NumBer == index ? false : true ">
                  {{ item[xiang] }}
              </div>
                <input  v-else type="text" v-model="item[xiang]" name="" value="">
            </td>
            <td>
              <button @click="XiuGai(index)" class="btn" v-if="NumBer == index ? false : true "  type="button" name="button">修改</button>
              <button @click="ChengGong()" class="btn-new" v-else  type="button" name="button">完成</button>
            </td>
          </tr>
        </table>
</template>
<script>
export default {
  name: 'Tables',
  props:{
    TableMsg:{
      type:Array
    },
    TdMsg:{
      type:Array
    },
    ArrMsg:{
      type:Array
    },
    XiuGai:{
      type:Function
    },
    ChengGong:{
      type:Function
    },
    NumBer:Number
  },
  data() {
    return {

    }
  },
  beforeMount:function(){
    console.log(this.XiuGai);
    console.log(this.ChengGong);
  }

}
</script>

<style scoped>

td{
  border:1px solid #ccc;

  text-align:center;

  line-height: 28px;
}
div{
  height:100%;
  width:100%;
}
.btn{
  border:none;
  outline:none;
  background:rgb(86,210,205);
  color:white;
  border-radius:4px;
}
.btn-new{
  border:none;
  outline:none;
  background:rgb(25,121,254);
  color:white;
  border-radius:4px;
}
input{
  outline:none;
  width:100%;
  height:100%;
  line-height: 100%;
  border:1px solid blue;
}
</style>
