<template>
  <div class="model">
    <div class="modelContent">
        <tr>
          <td v-for="item in ModelMsg">{{ item }}</td>
        </tr>
        <tr>
          <td v-for="item in InputMsg">
            <slot :name="`${item}`"></slot>
          </td>
        </tr>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Model',
  props:{
    ModelMsg:{
      type:Array
    },
    InputMsg:{
      type:Array
    }
  },
  data() {
    return {
    }
  }

}
</script>

<style scoped>
.model{
  width:100%;
  height:100%;
  position:absolute;
  left:0px;
  top:0px;
  background:rgba(0,0,0,0.6);
  z-index:9999;
}
.modelContent{
  background:white;
  width:1400px;
  height:150px;
  margin:100px auto;
  overflow:hidden;
}
td{
  border:1px solid #ccc;
  width:330px;
  text-align:center;
  height:28px;
  line-height: 28px;
}

</style>
