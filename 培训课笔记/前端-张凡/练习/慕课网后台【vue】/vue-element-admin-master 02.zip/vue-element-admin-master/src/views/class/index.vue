<template>
  <div class="app-container">

    <h1>这是课程列表</h1>

  </div>
</template>

<script>

export default {
  name: 'ClassList'

}
</script>
