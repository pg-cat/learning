<template>
  <div class="">

    <h1>这是课程内容页面</h1>

  </div>
</template>

<script>

export default {
  
  name: 'ClassContent',

}
</script>
