#   微信小程序

    如果微信小程序要上线，必须在微信公众平台注册
    
    一个邮箱只能绑定微信小程序/微信公众号/微信服务号/微信开发者接口中的一个
    
##  关闭https验证

    微信小程序的所有后台接口，必须要满足一下三个条件:
    
    1. 必须含有https协议
    
    2. 域名必须备案
    
    3. 必须设置安全域名，否则请求会出现502
    
    项目设置->本地设置里面，勾选取消安全验证
    
##  微信小程序模块

    组件      标签
    
    api      内置方法
    
### 配置      

    导航栏配置等等
    
    pages   所有的页面导航
    
        如果要添加页面，直接在app.json的pages对象中添加即可
        
    windows 
    
        配置页面的导航栏颜色，字体颜色等等
        
### 组件

    view     div
    
    text     span
    
    swiper/swiper-item   轮播图
    
    bindtap   微信的组件属性，相当于onclick
    
    通过组件进行页面跳转有两种方式:
    
        1. navigator 标签，类似于a标签，通过url进行跳转
        
        2. 绑定事件，调用wx对的api:wx.navigateTo({
                                url: '../logs/logs'
                              })
                              
    注意：如果要获取用户信息，需要有一个空白页面进行获取信息，并且跳转
    
    wx.login    微信登录
    
        success 成功
        
        fail    失败
        
    wx.getUserInfo  获取用户信息
    
        encryptedData   用户的完整加密数据
        
        iv  加密算法向量，需要和上面的数据配合进行使用
        
    wx.startLocationUpdate  获取用户地理位置
    
        一般情况下，我们都是用该方法获取用户权限之后，在进行定位
        
        在一种情况下会报错:手机设置关闭了位置信息，会一直报错
        
    跳转页面传递参数，需要和get请求一样的操作
    
        只能携带字符串进行跳转，所以一般建议，携带token或者appid到新页面之后重新请求数据
        
    网页登录->服务器返回token
    
    微信登录->返回另一个token2(appid)
    
    获取本服务的appid:wx.getAccountInfoSync()
    
    
    
    

    
