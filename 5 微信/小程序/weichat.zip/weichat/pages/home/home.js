// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    swiperList:[],
    userInfos:''
  },
  getData(){
    console.log(this);
    var _this = this;
    wx.request({
      url: 'http://localhost:3000/getSwiper',
      method:'get',
      success:function(res){
        console.log(res);
        console.log(this);
        _this.setData({
          swiperList : res.data.data
        })
      }
    })
  },
  shuchu(){
    //  vue中this.数据,this.data.数据
    console.log(this.data.swiperList);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var _this = this;
    //  获取用户数据
    wx.login({
      success:function(res){
        console.log(res);
        wx.getUserInfo({
          success:function(response){
            console.log(response);
            _this.setData({
              userInfos:response.userInfo
            })
          }
        })  
        //  获取用户地理位置
        wx.startLocationUpdate({
          success: function (response){
            console.log("地理位置"  + response);
          }
        })
        wx.getSetting({
          success:function(shunge){
            console.log(shunge);
            //  shunge.authSetting 用户同意你获取的权限
            //  scope.userInfo  用户允许你获取用户的基本信息
            //  scope.userLocation 地理位置
            //  摄像头
            //  内存
            //  通讯录
          }
        })
      }
    })
  },
  nav(){
    var data = JSON.stringify(this.data.userInfos)
    wx.navigateTo({
      url: "../details/details?data=" + data
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.log(wx.getAccountInfoSync())
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

})