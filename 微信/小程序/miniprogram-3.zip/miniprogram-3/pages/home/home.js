// pages/home/home.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    search:'',
    swiperList:[],
    classList:[],
    bookList:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  onReady: function () {
    const _this = this;
    wx.request({
      url: 'http://localhost:3000/home',
      success:function(res){
        console.log(res.data);
        _this.setData({
          swiperList:res.data[0],
          classList:res.data[1],
          bookList:res.data[2]
        })
      }
    })
    //  引入子组件并且实例化
    this.book = this.selectComponent("#book");
  },

  getSearch(){
    
    //  发送ajax请求
    //  搜索书籍，信息返回之后
    if(this.data.search !== ''){
      wx.navigateTo({
        url: '../details/details?search=' + this.data.search,
      })
    }
  },
  shuru(event){
    console.log();
    this.setData({
      search: event.detail.value
    })
  },
  chuanzhi(){
    console.log('translate');
  },
  change(){
    // var obj = this.data.bookList;
    // obj[0].tag = '文学';
    // this.setData({
    //   bookList: obj
    // })
    console.log(this.book.data.bookmsg);
    this.book.setData({
      bookmsg:'修改后的信息'
    })
  }
})