//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    nickName:'',
    avatarUrl:'',
    latitude:'',
    longitude:''
  },

  onLoad: function () {
    const _this = this;
   // 微信第三方登录
   wx.login({
     success:function(res){
     // 此处返回的内容包含了code
      //  获取用户基本信息
      wx.getUserInfo({
        success:function(response){
          //  和第三方服务器进行交互，交互之后获取用户的openid以及session_key
          wx.request({
            url: 'http://192.168.0.102:3000/wxlogin',
            method:'get',
            data:{
              code: res.code,
              encryptedData: response.encryptedData,
              iv: response.iv,
              signature: response.signature,
              userInfo: response.userInfo
            },
            success:function(res){
              _this.setData({
                nickName: res.data.nickName,
                avatarUrl: res.data.avatarUrl
              })
              
            }
          })
        }
      })
     }
   })
  },
  getAddress(){
    const _this = this;
    wx.getSetting({
      success:function(res){
        //  res.authSetting.scope.userLocation == true   用户授权可以进行定位
        //  res.authSetting.scope.userLocation == false  用户拒绝授权进行定位
        //  res.authSetting.scope.userLocation == undefined  用户没有授权进行定位
        if (res.authSetting['scope.userLocation'] == true){
          //  获取用户位置
          wx.getLocation({
            isHighAccuracy:true,
            success: function (datas) {
              wx.showToast({
                title: '成功',
                icon: 'success',
                duration: 2000
              })
              
              _this.setData({
                latitude: datas.latitude,
                longitude: datas.longitude
              })
            },
          })
        } else if (res.authSetting['scope.userLocation'] == false || res.authSetting['scope.userLocation'] == undefined){
          wx.showModal({
            title: '授权提醒',
            content: '是否允许我们获取你的位置',
            success(res) {
              if (res.confirm) {  
                //  获取用户位置
                wx.getLocation({
                  success: function(datas) {
                    _this.setData({
                      latitude: datas.latitude,
                      longitude: datas.longitude
                    })
                  },
                })
              } else if (res.cancel) {
                console.log('用户点击取消')
              }
            }
          })
        }
      }
    })
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '这是宏毅的微信小程序',
      path: '/pages/index/index'
    }
  }
})
