//logs.js
const util = require('../../utils/util.js')

const app = getApp()

Page({
  data: {
    logs: []
  },
  onLoad: function () {
    console.log(app.globalData.shuju)
  }
})
