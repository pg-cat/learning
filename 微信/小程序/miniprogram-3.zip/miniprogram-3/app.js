//app.js
App({
  shuchu(){
    console.log('这里是输出信息');
  },

  onLaunch: function () {
  
  },
  globalData: {
    shuju: '这里是数据'
  },
  
})